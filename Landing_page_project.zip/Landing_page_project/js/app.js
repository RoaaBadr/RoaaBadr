//To the Top of the page btn

window.onscroll = function() {ScrollDown()};
let btn = document.getElementById('btnID');

function ScrollDown()
{
    const scrollTopbody = document.body.scrollTop;
    if (scrollTopbody > 20 ) 
    {
        btn.style.display = "block";
    }
    else
    {
        btn.style.display = "none";
    }
}
function scrollToTop() {

    window.scrollTo({top: 0, behavior: 'smooth'});
    
}

//global var

const menu = document.getElementById('navbar__list'); 
const sections = Array.from(document.querySelectorAll('section')); 
let numberoflistitems = sections.length; //  length(4)


// event link
window.addEventListener("scroll", () => {
     
    sections.forEach(section => 
        {
        let aLiNk = document.querySelectorAll("a");
        let dataNavV = section.getAttribute("data-nav");
        let navPosition = section.getBoundingClientRect(); 
        let cond = navPosition.top > 0 && navPosition.top <= 300;
        if (cond) {
            // for all sections
        section.classList.add("your-active-class"); 
        aLiNk.forEach(link => {
          let condition= link.textContent;
          if (condition === dataNavV) {
            link.classList.add("your-active-class");
            } 
            else
            {
                link.classList.remove("your-active-class");
            }
            });
        } else {
        section.classList.remove("your-active-class");
        }
    });
});

//creat menu items

function createListItem(){
    for (section of sections){
        sectionName = section.getAttribute('data-nav'); 
        sectionLink = section.getAttribute('id'); 
        //create the item for each one
        listItem = document.createElement('li'); 
        listItem.innerHTML = `<a href='#${sectionLink}' class="menu__link" >${sectionName}</a>`;
        menu.appendChild(listItem);
    }
}
createListItem();

//-----------smooth scroll
document.getElementById('nav--bar').addEventListener('click', function (e) {
    e.preventDefault();
    const target = e.target;
    if (target.classList.contains('menu__link')) {
        const id = target.getAttribute('href').slice(1);
        document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
    }
});
